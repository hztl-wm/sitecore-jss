/* eslint-disable no-unused-vars */
import { CommonFieldTypes, Manifest, SitecoreIcon, TemplateDefinition } from '@sitecore-jss/sitecore-jss-manifest';

export default function(manifest) {

    const newsTemplateSection = 'News';
    // News Route template in Sitecore
    manifest.addRouteType({
        name: 'News Route',
        icon: SitecoreIcon.DocumentEmpty,
        fields: [{
            name: 'newsTitle',
            displayName: 'News Title',
            section: newsTemplateSection,
            type: CommonFieldTypes.SingleLineText
        },
        {
            name: 'newsDescription',
            displayName: 'News Description',
            section: newsTemplateSection,
            type: CommonFieldTypes.RichText
        },
        {
            name: 'newsImage',
            displayName: 'News Image',
            section: newsTemplateSection,
            type: CommonFieldTypes.Image
        }],
        insertOptions: ['News Route']
    });
}