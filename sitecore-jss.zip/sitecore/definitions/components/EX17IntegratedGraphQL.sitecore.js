// eslint-disable-next-line no-unused-vars
import { CommonFieldTypes, SitecoreIcon, Manifest } from '@sitecore-jss/sitecore-jss-manifest';
import fs from 'fs';
const query = fs.readFileSync('sitecore/definitions/components/EX17IntegratedGraphQL.sitecore.graphql', 'utf8');

/**
 * Adds the EX17IntegratedGraphQL component to the disconnected manifest.
 * This function is invoked by convention (*.sitecore.js) when 'jss manifest' is run.
 * @param {Manifest} manifest Manifest instance to add components to
 */
export default function(manifest) {
  manifest.addComponent({
    name: 'EX17IntegratedGraphQL',
    icon: SitecoreIcon.DocumentTag,
    graphQLQuery: query,
    fields: [
      { name: 'SingleItem1', type: CommonFieldTypes.ItemLink },
      { name: 'MultiItem1', type: CommonFieldTypes.ContentList },
    ],
    allowedPlaceholders: ["jss-main"]
    /*
    If the component implementation uses <Placeholder> or withPlaceholder to expose a placeholder,
    register it here, or components added to that placeholder will not be returned by Sitecore:
    placeholders: ['exposed-placeholder-name']
    */
  });
}
