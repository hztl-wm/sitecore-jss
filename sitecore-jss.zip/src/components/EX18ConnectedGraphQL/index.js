import React from 'react';
import { Text } from '@sitecore-jss/sitecore-jss-react';
import { Link as RouterLink } from 'react-router-dom';
import { loader as gqlLoader } from 'graphql.macro';
import GraphQLData from '../../lib/GraphQLData';

const ConnectedDemoQuery = gqlLoader('./query.graphql');

const EX18ConnectedGraphQL = (props) => {
    const graphQLResult = props.connectedQuery;
    const { error, loading } = graphQLResult;
    const { item } = graphQLResult;
    return (<div>
        <h5>Connected GraphQL Sample</h5>
        { loading && <p className="alert alert-info">GraphQL query is executing...</p> }
        { error && <p className="alert alert-danger">GraphQL query error: {error.toString()}</p> }
        { item && (
            <ul>
                {item.parent.children.map((c, i) => (
                    <li key={i}>
                        <RouterLink to={c.url}>{c.name}</RouterLink>
                    </li>
                ))}
            </ul>
        )}
    </div>);
}
export default GraphQLData(ConnectedDemoQuery, {name: 'connectedQuery'})(EX18ConnectedGraphQL);