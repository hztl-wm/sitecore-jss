import React from 'react';
import { Text } from '@sitecore-jss/sitecore-jss-react';
const EX03Simple = (props) => (
    <div>
        <p>EX03Simple Component</p>
        <Text field={props.fields.heading} />
    </div>
);
export default EX03Simple;