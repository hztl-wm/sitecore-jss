import React from 'react';
import { Text } from '@sitecore-jss/sitecore-jss-react';
import { withTranslation } from 'react-i18next';

const EX14Translation = (props) => {
  let {fields, t} = props;
    return (
  <div>
    <h5>EX14Translation Component</h5>
    {t('MyLabel')}: <Text field={fields.heading} />
  </div>
  );
}

export default withTranslation()(EX14Translation);
