import React from 'react';
import { withSitecoreContext, Text, RichText, Image } from '@sitecore-jss/sitecore-jss-react';

const EX12News = (props) => (
  <div>
    <p>EX12News Component</p> 
    { props.sitecoreContext.route && 
    <div>
      <br/> 
      News Title Field : <Text field={props.sitecoreContext.route.fields.newsTitle} /> 
      <br/> 
      News Description Field : <RichText field={props.sitecoreContext.route.fields.newsDescription} /> 
      <br/> 
      News Image Field : <Image field={props.sitecoreContext.route.fields.newsImage} />
    </div>
    }
  </div>
);

export default withSitecoreContext()(EX12News);
