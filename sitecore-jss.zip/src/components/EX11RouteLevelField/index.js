import React from 'react';
import { withSitecoreContext, Text } from '@sitecore-jss/sitecore-jss-react';

const EX11RouteLevelField = (props) => (
  <div>
    <p>EX11RouteLevelField Component</p>
    {props.sitecoreContext.route &&
    <div>
      Page Title: <Text field={props.sitecoreContext.route.fields.pageTitle} />
    </div>
    }
  </div>
);

export default withSitecoreContext()(EX11RouteLevelField);
