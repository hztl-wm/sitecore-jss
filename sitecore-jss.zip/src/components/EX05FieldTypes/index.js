import React from 'react';
import { Text, RichText, Image, Link, DateField, File, getFieldValue } from '@sitecore-jss/sitecore-jss-react';

const EX05FieldTypes = (props) => (
  <div>
    <h2>EX05FieldTypes Component</h2>
    <Text field={props.fields.heading} />
    <br/> Text Field: <Text field={props.fields.textfield} />
    <br/> RichText Field: <RichText field={props.fields.richtextfield} />
    <br/> Image Field: <Image field={props.fields.imagefield} />
    <br/> Checkbox1 Field: 
    {getFieldValue(props.fields, 'checkboxfield1', false) &&
    <span>true</span>
    }
    {!getFieldValue(props.fields, 'checkboxfield1', false) &&
    <span>false</span>
    }
    <br/> Checkbox2 Field:
    {props.fields &&
      props.fields.checkboxfield2 &&
        props.fields.checkboxfield2.value &&
        <span>true</span>
    }
    {!props.fields ||
    !props.fields.checkboxfield2 ||
      (!props.fields.checkboxfield2.value &&
        <span>false</span>
      )
    }
    <br/> General Link Field: <Link field={props.fields.generallinkfield} />
    <br/> Date Field: <DateField field={props.fields.datefield} />
    <br/> File Field: <File field={props.fields.filefield} />
  </div>
);

export default EX05FieldTypes;
