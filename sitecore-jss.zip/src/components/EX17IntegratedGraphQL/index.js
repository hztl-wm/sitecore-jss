import React from 'react';
import { Link } from 'react-router-dom';
import { Text } from '@sitecore-jss/sitecore-jss-react';

const EX17IntegratedGraphQL = (props) => {
  let data = props.fields.data;
  return (
  <div>
    <h5>Integrated GraphQL Sample</h5>
    { data && data.datasource.singleItem1 &&
    <Text field={data.datasource.singleItem1.targetItem.pageTitle.jss} />
    }
    { data && data.datasource.multiItem1 && 
    <ul>
      {data.datasource.multiItem1.targetItems.map((value, index) => (
        <li key={index}>
          <Link to={value.url}><Text field={value.pageTitle} /></Link>
        </li>
      ))}
    </ul>
    }
  </div>);
}

export default EX17IntegratedGraphQL;
