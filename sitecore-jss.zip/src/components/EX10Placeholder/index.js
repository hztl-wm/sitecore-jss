import React from 'react';
import { Placeholder } from '@sitecore-jss/sitecore-jss-react';

const EX10Placeholder = (props) => (
  <div className="row">
    <div className="col">
      <Placeholder name="jss-left" rendering={props.rendering} />
    </div>
    <div className="col">
      <Placeholder name="jss-right" rendering={props.rendering} />
    </div>
  </div>
);

export default EX10Placeholder;
