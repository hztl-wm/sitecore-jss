import React from 'react';
import { Text, RichText, Link } from '@sitecore-jss/sitecore-jss-react';

const CL01Jumbotron = (props) => (
  <div class="jumbotron">
    <h1 class="display-4"><Text field={props.fields.teaserTitle} /></h1>
    <p class="lead"><Text field={props.fields.teaserSummary} /></p>
    <RichText field={props.fields.teaserBody} />
    <Link field={props.fields.teaserLink} className="btn btn-primary btn-lrg" role="button">
      Learn More
    </Link>
  </div>
);

export default CL01Jumbotron;
