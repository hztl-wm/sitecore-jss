import React from 'react';
import { withSitecoreContext } from '@sitecore-jss/sitecore-jss-react';

const EX13SitecoreContext = (props) => (
  <div>
    <h5>EX13SitecoreContext Component</h5>
    <pre style={{ maxHeight: '400px', overflow: 'scroll'}}>
      {JSON.stringify(props.sitecoreContext, null, 2)}
    </pre>
  </div>
);

export default withSitecoreContext()(EX13SitecoreContext);
