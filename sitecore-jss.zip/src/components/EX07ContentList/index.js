import React from 'react';
import { Text } from '@sitecore-jss/sitecore-jss-react';

const EX07ContentList = (props) => (
  <div>
    <h5>Shared Content List</h5>
    <ul>
      {props.fields.sharedContentList &&
      props.fields.sharedContentList.map((item, index) => (
        <li key={`sharedContentList-${index}`}>
          Field: <Text field={item.fields.textField} />
        </li>
      ))}
    </ul>
    <h5>Local Content List</h5>
    <ol>
      {props.fields.localContentList &&
      props.fields.localContentList.map((item, index) => (
        <li key={`localContentList-${index}`}>
          Field: <Text field={item.fields.textField} />
        </li>
      ))}
    </ol>
  </div>
);

export default EX07ContentList;
