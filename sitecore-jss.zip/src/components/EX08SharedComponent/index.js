import React from 'react';
import { Text, RichText } from '@sitecore-jss/sitecore-jss-react';

const EX08SharedComponent = (props) => (
  <div>
    <h5>EX08SharedComponent Component</h5>
    <Text field={props.fields.heading} />
    <RichText field={props.fields.content} />
  </div>
);

export default EX08SharedComponent;
