import React from 'react';
import { Text, RichText } from '@sitecore-jss/sitecore-jss-react';

const EX04RichText = (props) => (
  <div>
    <p>EX04RichText Component</p>
    <Text field={props.fields.heading} />
    <RichText field={props.fields.content} />
  </div>
);

export default EX04RichText;
