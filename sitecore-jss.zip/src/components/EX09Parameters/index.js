import React from 'react';
import { Text } from '@sitecore-jss/sitecore-jss-react';

const EX09Parameters = (props) => (
  <div>
    <h5>EX09Parameters Component</h5>
    <div className={props.params.cssClass}>
      <Text field={props.fields.heading} />
    </div>
    <span>message: {props.params.message}</span>
  </div>
);

export default EX09Parameters;
